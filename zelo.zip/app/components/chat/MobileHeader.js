'use client'

import Conversations from "./Conversations"
import FriendsList from "./FriendsList"
import PinnedMessages from "./PinnedMessages"
import SearchBar from "./SearchBar"
import { getConsistentAvatar } from './chat/DefaultAvatars'

export default function MobileHeader() {
    
    return (
        <div className="">
            <FriendsList onUserSelect={handleUserSelect} onlineUsers={onlineUsers} theme={theme} />
            <SearchBar />
            {/* <div className='h-full'>
                <div className='h-full flex flex-col md:block gap-2 p-[.4rem] bg-card-light-outer dark:bg-card-dark-outer rounded-xl
                                                    border border-card-stroke-light dark:border-card-stroke-dark'>
                    <PinnedMessages
                        conversations={conversations.filter(c => c.isPinned)}
                        onUserSelect={handleUserSelect}
                        refreshConversations={fetchFriends}
                        getAvatar={getConsistentAvatar}
                    />
                    <Conversations
                        conversations={conversations}
                        onUserSelect={handleUserSelect}
                        onDeleteConversation={handleDeleteConversation}
                        onlineUsers={onlineUsers}
                        refreshConversations={fetchFriends}
                        getAvatar={getConsistentAvatar}
                    />
                </div>
            </div> */}
        </div>
    )
}
'use client'

export default function NotificationPage() {
    return (
        <div className="flex flex-col items-center justify-center h-full">
            <h1 className="text-2xl font-bold mb-4">Notification Page</h1>
            <p className="text-gray-600">This is the notification page content.</p>
        </div>
    )
}
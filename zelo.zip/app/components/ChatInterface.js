'use client'


import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { io } from 'socket.io-client';
import ChatDesktopView from './ChatDesktopView';

export default function ChatInterface({ ViewComponent }) {
    const { data: session } = useSession()
    const [selectedUser, setSelectedUser] = useState(null)
    const [conversations, setConversations] = useState([])
    const [socket, setSocket] = useState(null)
    const [messages, setMessages] = useState([])
    const [onlineUsers, setOnlineUsers] = useState([])
    const [typingStatus, setTypingStatus] = useState(false)
    const selectedUserRef = useRef(null)
    const [theme, setTheme] = useState('light')

    useEffect(() => {
        if (!session?.user?.id) return
        selectedUserRef.current = selectedUser

        const newSocket = io('http://localhost:3003', {
            path: '/socket.io',
            transports: ['websocket'],
            withCredentials: true,
        })

        newSocket.on('connect', () => {
            console.log('Socket connected')
            newSocket.emit('join', `user:${session.user.id}`, session.user.id)
            newSocket.emit('online', { userId: session.user.id })
        })

        newSocket.on('disconnect', (reason) => {
            console.log('Socket disconnected:', reason)
        })

        newSocket.on('message:receive', async (message) => {
            const currentSelectedUser = selectedUserRef.current;

            // Add the message to the chat window if the conversation is selected
            if (currentSelectedUser && (message.senderId === currentSelectedUser.id || message.receiverId === currentSelectedUser.id)) {
                setMessages(prev => {
                    if (prev.some(m => m.id === message.id)) return prev;
                    return [...prev, message];
                });
                console.log("MESSAGE", message);

                // Auto mark as seen if the incoming message is from the selected user
                if (message.senderId === currentSelectedUser.id) {
                    try {
                        await fetch('/api/messages/mark-seen', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ userId: currentSelectedUser.id })
                        });
                        // Refresh conversations to update unread status
                        await fetchFriends();
                    } catch (error) {
                        console.error('Failed to mark message as seen:', error);
                    }
                }
            } else {
                // Update the conversation list with the new message
                setConversations(prev => {
                    if (!prev.length) {
                        return [{
                            id: message.senderId,
                            unread: true,
                            lastMessage: message.content,
                            name: message.sender?.name || 'Unknown',
                            image: message.sender?.image || null,
                        }];
                    }
                    console.log("ID", id);


                    const updated = prev.map(c => {
                        console.log('Checking match:', { cId: c.id, senderId: message.senderId });
                        if (c.id === message.senderId) {
                            console.log("MATCH FOUND: Updating conversation");
                            return { ...c, unread: true, lastMessage: message.content };
                        }
                        return c;
                    });
                    console.log("MESSAGE", updated);
                    return updated;
                });

                // Trigger a background refresh if needed
                await fetchFriends();
            }
        });

        newSocket.on('typing:start', (data) => {
            const currentSelectedUser = selectedUserRef.current
            if (currentSelectedUser && data.senderId === currentSelectedUser.id) {
                setTypingStatus(true)
            }
        })

        newSocket.on('typing:stop', (data) => {
            const currentSelectedUser = selectedUserRef.current
            if (currentSelectedUser && data.senderId === currentSelectedUser.id) {
                setTypingStatus(false)
            }
        })

        newSocket.on('user:online', ({ userId }) => {
            setOnlineUsers(prev => [...new Set([...prev, userId])])
        })

        newSocket.on('user:offline', ({ userId }) => {
            setOnlineUsers(prev => prev.filter(id => id !== userId))
        })

        const handleBeforeUnload = () => {
            newSocket.emit('offline', {
                userId: session.user.id,
                lastSeen: new Date().toISOString()
            })
        }

        window.addEventListener('beforeunload', handleBeforeUnload)

        setSocket(newSocket)

        return () => {
            newSocket.emit('offline', {
                userId: session.user.id,
                lastSeen: new Date().toISOString()
            })

            if (newSocket.connected) {
                newSocket.off('message')
                newSocket.off('typing:start')
                newSocket.off('typing:stop')
                newSocket.off('user:online')
                newSocket.off('user:offline')
                newSocket.disconnect()
            }

            window.removeEventListener('beforeunload', handleBeforeUnload)
        }
    }, [session, selectedUser])

    useEffect(() => {
        if (conversations.length === 0) {
            setSelectedUser(null)
            setMessages([])
        }
    }, [conversations])

    useEffect(() => {
        if (session?.user?.id) {
            fetchFriends()
            const interval = setInterval(fetchFriends, 5000)
            return () => clearInterval(interval)
        }
    }, [session?.user?.id])

    // Sync theme with localStorage (optional)
    useEffect(() => {
        const savedTheme = localStorage.getItem('theme') || 'light'
        setTheme(savedTheme)
        document.documentElement.classList.toggle('dark', savedTheme === 'dark')
    }, [])

    // Theme toggler
    const toggleTheme = () => {
        const newTheme = theme === 'light' ? 'dark' : 'light'
        setTheme(newTheme)
        localStorage.setItem('theme', newTheme)
        document.documentElement.classList.toggle('dark', newTheme === 'dark')
    }

    // Fetch friends
    const fetchFriends = async () => {
        try {
            const response = await fetch('/api/friends/list')
            if (!response.ok) throw new Error('Failed to fetch friends')
            const data = await response.json()
            setConversations(data)
            console.log("✅ Updated conversations:", data)
        } catch (err) {
            console.error('Error fetching friends:', err)
        }
    }

    const handleUserSelect = async (user) => {
        setSelectedUser(user)
        try {
            const response = await fetch(`/api/messages?userId=${user.id}`)
            if (!response.ok) throw new Error('Failed to fetch messages')
            const data = await response.json()
            setMessages(data)
        } catch (error) {
            console.error('Error fetching messages:', error)
        }
        await fetch('/api/messages/mark-seen', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: user.id })
        })
    }

    const handleSendMessage = async (content) => {
        if (!selectedUser) return
        try {
            const response = await fetch(`/api/messages`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content, receiverId: selectedUser.id })
            })
            if (!response.ok) throw new Error('Failed to send message')
            const message = await response.json()

            socket.emit('chat:message', {
                ...message,
                receiverId: selectedUser.id,
                senderId: session.user.id,
                senderName: session.user.name,
                senderImage: session.user.image
            })

            setMessages(prev => [...prev, { ...message, isSender: true }])
        } catch (error) {
            console.error('Error sending message:', error)
        }
    }

    const handleTyping = (isTyping) => {
        if (!socket || !selectedUser) return
        const event = isTyping ? 'typing:start' : 'typing:stop'
        socket.emit(event, {
            senderId: session.user.id,
            receiverId: selectedUser.id
        })
    }

    const handleDeleteConversation = async (conversationId) => {
        try {
            const response = await fetch('/api/conversations/delete', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ conversationId })
            })

            if (!response.ok) {
                throw new Error('Failed to delete conversation')
            }

            if (selectedUser?.id === conversationId) {
                setSelectedUser(null)
                setMessages([])
            }

            await fetchFriends()
        } catch (error) {
            console.error('Error deleting conversation:', error)
        }
    }

    return (
        <ViewComponent
            session={session}
            selectedUser={selectedUser}
            conversations={conversations}
            messages={messages}
            onlineUsers={onlineUsers}
            typingStatus={typingStatus}
            theme={theme}
            handleUserSelect={handleUserSelect}
            handleSendMessage={handleSendMessage}
            handleTyping={handleTyping}
            handleDeleteConversation={handleDeleteConversation}
            fetchFriends={fetchFriends}
            toggleTheme={toggleTheme}
        />
    );
}


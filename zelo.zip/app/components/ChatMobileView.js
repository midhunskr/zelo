import BottomTabBar from "./chat/BottomTabBar";
import Conversations from "./chat/Conversations";
import MobileHeader from "./chat/MobileHeader";
import PinnedMessages from "./chat/PinnedMessages";
console.log('MobileHeader:', MobileHeader)
console.log('BottomTabBar:', BottomTabBar)


export default function ChatMobileView({
  // session,
  // selectedUser,
  // conversations,
  // messages,
  onlineUsers,
  // typingStatus,
  theme,
  handleUserSelect,
  // handleSendMessage,
  // handleTyping,
  // handleDeleteConversation,
  // fetchFriends,
  // toggleTheme,
  children
}) {
  return (
    <div className="flex flex-col h-full">
      <div className='md:hidden p-4 flex flex-col gap-4 h-screen'>
        <FriendsList onUserSelect={handleUserSelect} onlineUsers={onlineUsers} theme={theme} />
        <SearchBar />
        <div className='h-full'>
          {children}
        </div>
        <BottomTabBar />
      </div>
    </div>  )
}
